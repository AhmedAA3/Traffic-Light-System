/*
 * Traffic_logic.h
 *
 *  Created on: Dec 9, 2025
 *      Author: lukasnoel
 */

#ifndef INC_TRAFFIC_LOGIC_H_
#define INC_TRAFFIC_LOGIC_H_

void trafficlight(void);

#endif /* INC_TRAFFIC_LOGIC_H_ */
